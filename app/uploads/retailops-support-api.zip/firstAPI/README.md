# firstAPI - RetailOps FastAPI

This project converts the original Django REST Framework RetailOps support API into FastAPI.

## 1. Open the project in VS Code

Open the `firstAPI` folder.

## 2. Create a virtual environment

### Windows PowerShell

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, you can run the server without activating the environment:

```powershell
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload
```

## 3. Install packages

```powershell
python -m pip install -r requirements.txt
```

## 4. Start FastAPI

Use this command in the VS Code terminal:

```powershell
python -m uvicorn app.main:app --reload
```

You should see the server at:

```text
http://127.0.0.1:8000
```

## 5. Open Swagger documentation

```text
http://127.0.0.1:8000/docs
```

## Endpoints

- `GET /` - health check
- `GET /api/customers` - cleaned and deduplicated customers
- `GET /api/orders` - orders excluding cancelled orders
- `GET /api/orders?status=paid` - case-insensitive status filter
- `GET /api/orders?include_cancelled=true` - include cancelled orders
- `GET /api/orders/{order_id}` - get one order
- `GET /api/dashboard` - dashboard revenue summary

## Run tests

```powershell
python -m pytest -q
```

Expected result:

```text
8 passed
```

## Expected dashboard

```json
{
  "generated_for": "ops-dashboard",
  "total_paid_orders": 3,
  "revenue": 4996.06,
  "average_order_value": 1665.35,
  "top_region": "North"
}
```
