from pydantic import BaseModel


class Customer(BaseModel):
    customer_id: str
    name: str
    email: str
    region: str


class OrderItem(BaseModel):
    sku: str
    qty: int
    unit_price: float


class Order(BaseModel):
    order_id: str
    customer_id: str
    status: str
    ordered_at: str
    items: list[OrderItem]
    discount_percent: float
    total: float


class Dashboard(BaseModel):
    generated_for: str
    total_paid_orders: int
    revenue: float
    average_order_value: float
    top_region: str | None
