from __future__ import annotations

import csv
import json
from datetime import datetime
from pathlib import Path
from typing import Any

DATA_DIR = Path(__file__).resolve().parent / "data"


def load_orders() -> list[dict[str, Any]]:
    with (DATA_DIR / "orders.json").open(encoding="utf-8") as file:
        return json.load(file)


def load_customers() -> list[dict[str, str]]:
    # Normalize fields and remove duplicate customers by normalized email.
    with (DATA_DIR / "customers.csv").open(
        encoding="utf-8", newline=""
    ) as file:
        rows = csv.DictReader(file)

        customers: list[dict[str, str]] = []
        seen_emails: set[str] = set()

        for row in rows:
            email = row["email"].strip().lower()
            if email in seen_emails:
                continue

            seen_emails.add(email)
            customers.append(
                {
                    "customer_id": row["customer_id"].strip(),
                    "name": row["name"].strip(),
                    "email": email,
                    "region": row["region"].strip().title(),
                }
            )

        return customers


def normalize_date(raw_date: str) -> str:
    raw_date = (raw_date or "").strip()

    for date_format in ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(raw_date, date_format).date().isoformat()
        except ValueError:
            continue

    return "invalid"


def calculate_order_total(order: dict[str, Any]) -> float:
    subtotal = sum(
        item["qty"] * item["unit_price"]
        for item in order.get("items", [])
    )

    discount_percent = float(order.get("discount_percent") or 0)
    total = subtotal * (1 - discount_percent / 100)

    return round(total, 2)


def list_orders(
    status: str | None = None,
    include_cancelled: bool = False,
) -> list[dict[str, Any]]:
    orders = load_orders()

    if not include_cancelled:
        orders = [
            order for order in orders
            if order.get("status", "").lower() != "cancelled"
        ]

    if status:
        wanted_status = status.strip().lower()
        orders = [
            order for order in orders
            if order.get("status", "").lower() == wanted_status
        ]

    enriched_orders: list[dict[str, Any]] = []

    for order in orders:
        enriched_order = dict(order)
        enriched_order["ordered_at"] = normalize_date(
            order.get("ordered_at", "")
        )
        enriched_order["total"] = calculate_order_total(order)
        enriched_orders.append(enriched_order)

    # Valid ISO dates sort correctly. Invalid dates are placed last.
    enriched_orders.sort(
        key=lambda order: order["ordered_at"]
        if order["ordered_at"] != "invalid"
        else "",
        reverse=True,
    )

    return enriched_orders


def get_order_by_id(order_id: str) -> dict[str, Any] | None:
    for order in list_orders(include_cancelled=True):
        if order["order_id"] == order_id:
            return order
    return None


def revenue_summary(
    orders: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    if orders is None:
        orders = load_orders()

    # Build one lookup dictionary instead of scanning all customers
    # for every order.
    customers_by_id = {
        customer["customer_id"]: customer
        for customer in load_customers()
    }

    total_revenue = 0.0
    paid_order_count = 0
    region_totals: dict[str, float] = {}

    for order in orders:
        if order.get("status", "").lower() != "paid":
            continue

        order_total = calculate_order_total(order)
        total_revenue += order_total
        paid_order_count += 1

        customer = customers_by_id.get(order.get("customer_id"))
        if customer:
            region = customer["region"]
            region_totals[region] = (
                region_totals.get(region, 0.0) + order_total
            )

    top_region = (
        max(region_totals, key=region_totals.get)
        if region_totals
        else None
    )

    average_order_value = (
        round(total_revenue / paid_order_count, 2)
        if paid_order_count
        else 0.0
    )

    return {
        "generated_for": "ops-dashboard",
        "total_paid_orders": paid_order_count,
        "revenue": round(total_revenue, 2),
        "average_order_value": average_order_value,
        "top_region": top_region,
    }
