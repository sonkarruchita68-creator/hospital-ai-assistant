from fastapi import FastAPI, HTTPException, Query

from app.schemas import Customer, Dashboard, Order
from app.services import (
    get_order_by_id,
    list_orders,
    load_customers,
    revenue_summary,
)

app = FastAPI(
    title="RetailOps Support API",
    description="FastAPI version of the RetailOps support exercise",
    version="1.0.0",
)


@app.get("/")
def health():
    return {"status": "ok", "service": "retailops-support-api"}


@app.get("/api/customers", response_model=list[Customer])
def customers():
    return load_customers()


@app.get("/api/orders", response_model=list[Order])
def orders(
    status: str | None = Query(default=None),
    include_cancelled: bool = Query(default=False),
):
    return list_orders(status=status, include_cancelled=include_cancelled)


@app.get("/api/orders/{order_id}", response_model=Order)
def order_detail(order_id: str):
    order = get_order_by_id(order_id)
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    return order


@app.get("/api/dashboard", response_model=Dashboard)
def dashboard():
    return revenue_summary()
