from fastapi.testclient import TestClient

from app.main import app
from app import services

client = TestClient(app)


def test_health():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_customers_are_cleaned_and_deduplicated():
    customers = services.load_customers()
    assert len(customers) == 3
    assert customers[0]["email"] == "aditi@example.com"
    assert customers[0]["region"] == "East"
    assert customers[2]["region"] == "South"


def test_dates():
    assert services.normalize_date("11/06/2026") == "2026-06-11"
    assert services.normalize_date("13-06-2026") == "2026-06-13"
    assert services.normalize_date("2026-06-12") == "2026-06-12"
    assert services.normalize_date("invalid-date") == "invalid"


def test_discount():
    order = {
        "items": [{"qty": 2, "unit_price": 500.0}],
        "discount_percent": 10,
    }
    assert services.calculate_order_total(order) == 900.0


def test_orders_are_filtered_and_sorted():
    orders = services.list_orders()
    assert [o["order_id"] for o in orders] == [
        "ORD-1005", "ORD-1003", "ORD-1002", "ORD-1001"
    ]


def test_paid_filter_is_case_insensitive():
    response = client.get("/api/orders", params={"status": "PAID"})
    assert response.status_code == 200
    assert [o["order_id"] for o in response.json()] == [
        "ORD-1005", "ORD-1002", "ORD-1001"
    ]


def test_dashboard():
    response = client.get("/api/dashboard")
    assert response.status_code == 200
    assert response.json() == {
        "generated_for": "ops-dashboard",
        "total_paid_orders": 3,
        "revenue": 4996.06,
        "average_order_value": 1665.35,
        "top_region": "North",
    }


def test_order_not_found():
    response = client.get("/api/orders/DOES-NOT-EXIST")
    assert response.status_code == 404
    assert response.json()["detail"] == "Order not found"
